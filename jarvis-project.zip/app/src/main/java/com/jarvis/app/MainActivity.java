package com.jarvis.app;

import android.accounts.AccountManager;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    WebView w;
    TextToSpeech tts;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#02060B"));
        getWindow().setNavigationBarColor(Color.parseColor("#02060B"));
        tts = new TextToSpeech(this, s -> { if (s == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("es")); });
        w = new WebView(this);
        w.setBackgroundColor(Color.parseColor("#02060B"));
        WebSettings st = w.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        w.addJavascriptInterface(new Bridge(), "Android");
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }

    class Bridge {
        @JavascriptInterface public void speak(String t, float p, float r, String v) {
            runOnUiThread(() -> {
                if (v != null && !v.isEmpty()) {
                    Set<Voice> vs = tts.getVoices();
                    if (vs != null) for (Voice x : vs) if (x.getName().equals(v)) tts.setVoice(x);
                }
                tts.setPitch(p); tts.setSpeechRate(r);
                tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j");
            });
        }
        @JavascriptInterface public String voices() {
            StringBuilder sb = new StringBuilder();
            try { for (Voice x : tts.getVoices()) if (x.getLocale().getLanguage().equals("es")) sb.append(x.getName()).append("|"); } catch (Exception e) {}
            return sb.toString();
        }
        @JavascriptInterface public void pickGoogle() {
            runOnUiThread(() -> startActivityForResult(AccountManager.newChooseAccountIntent(null, null, new String[]{"com.google"}, null, null, null, null), 7));
        }
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == 7 && rs == RESULT_OK && d != null) {
            String n = d.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            if (n != null) w.evaluateJavascript("onGoogle('" + n.replace("'", "") + "')", null);
        }
    }

    @Override public void onBackPressed() {
        w.evaluateJavascript("(window.goBack&&goBack())?1:0", v -> { if (!"1".equals(v)) finish(); });
    }

    @Override protected void onDestroy() { if (tts != null) tts.shutdown(); super.onDestroy(); }
}
