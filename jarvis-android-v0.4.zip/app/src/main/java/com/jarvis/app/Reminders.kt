package com.jarvis.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

object Reminders {

    private const val PREFS = "jarvis_prefs"
    private const val CHANNEL = "jarvis_reminders"

    fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): JSONArray {
        return try {
            JSONArray(prefs(c).getString("reminders", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
    }

    fun save(c: Context, arr: JSONArray) {
        prefs(c).edit().putString("reminders", arr.toString()).apply()
    }

    fun add(c: Context, text: String, whenMs: Long): Int {
        val arr = load(c)
        val id = (System.currentTimeMillis() % 1000000000L).toInt() + 10
        val o = JSONObject()
        o.put("id", id)
        o.put("t", whenMs)
        o.put("text", text)
        arr.put(o)
        save(c, arr)
        schedule(c, "reminder", id, whenMs, text)
        return id
    }

    fun schedule(c: Context, kind: String, id: Int, whenMs: Long, text: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(c, AlarmReceiver::class.java)
        i.putExtra("kind", kind)
        i.putExtra("id", id)
        i.putExtra("text", text)
        val pi = PendingIntent.getBroadcast(
            c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(whenMs, show), pi)
    }

    fun cancel(c: Context, id: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            c, id, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    fun nextSummaryMs(h: Int, m: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, m)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    fun scheduleSummary(c: Context) {
        val p = prefs(c)
        if (!p.getBoolean("sum_on", false)) return
        val whenMs = nextSummaryMs(p.getInt("sum_h", 7), p.getInt("sum_m", 0))
        schedule(c, "summary", 1, whenMs, "")
    }

    fun scheduleSilence(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(c, AlarmReceiver::class.java)
        i.putExtra("kind", "silence")
        i.putExtra("id", 2)
        i.putExtra("text", "")
        val pi = PendingIntent.getBroadcast(
            c, 2, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 3L * 60L * 60L * 1000L, pi
        )
    }

    fun rescheduleAll(c: Context) {
        val now = System.currentTimeMillis()
        val arr = load(c)
        val keep = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("t") > now) {
                keep.put(o)
                schedule(c, "reminder", o.getInt("id"), o.getLong("t"), o.getString("text"))
            }
        }
        save(c, keep)
        scheduleSummary(c)
        if (prefs(c).getBoolean("sil_on", false)) scheduleSilence(c)
    }

    fun notify(c: Context, id: Int, title: String, text: String, cmd: String) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Avisos de Jarvis", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val i = Intent(c, MainActivity::class.java)
        i.putExtra("cmd", cmd)
        i.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        val pi = PendingIntent.getActivity(
            c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CHANNEL) else Notification.Builder(c)
        b.setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setStyle(Notification.BigTextStyle().bigText(text))
        nm.notify(id, b.build())
    }
}
