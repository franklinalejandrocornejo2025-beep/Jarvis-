package com.jarvis.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra("kind") ?: return
        val id = intent.getIntExtra("id", 0)
        val text = intent.getStringExtra("text") ?: ""
        if (kind == "summary") {
            Reminders.notify(context, 1, "Buenos días", "Toque para escuchar su resumen del día", "resumen")
            Reminders.scheduleSummary(context)
        } else if (kind == "silence") {
            val p = Reminders.prefs(context)
            if (p.getBoolean("sil_on", false)) {
                val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val n = p.getInt("pend_n", 0)
                val last = p.getLong("sil_last", 0L)
                if (h in 8..21 && n > 0 && System.currentTimeMillis() - last > 9000000L) {
                    Reminders.notify(
                        context, 4, "Jarvis",
                        "Tiene " + n + " tarea(s) pendiente(s). ¿Las revisamos?",
                        "orden: mis tareas"
                    )
                    p.edit().putLong("sil_last", System.currentTimeMillis()).apply()
                }
                Reminders.scheduleSilence(context)
            }
        } else {
            Reminders.notify(context, id, "Recordatorio", text, "recordatorio: " + text)
            val arr = Reminders.load(context)
            val keep = JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getInt("id") != id) keep.put(o)
            }
            Reminders.save(context, keep)
        }
    }
}
