package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class WakeService : Service() {

    companion object {
        @Volatile
        var paused = false

        @Volatile
        var active = false

        private const val CHANNEL = "jarvis_wake"
    }

    private var rec: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val wake = Regex(
        "(jarvis|yarvis|jervis|harvis|jarbis|yarbis|jarvi)[,\\s]*(.*)",
        RegexOption.IGNORE_CASE
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startAsForeground()
        } catch (e: Exception) {
            active = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (!active) {
            active = true
            handler.post { listen() }
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Escucha de Jarvis", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis escuchando")
            .setContentText("Diga Jarvis seguido de su orden")
            .setContentIntent(open)
            .setOngoing(true)
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1001, n)
        }
    }

    private fun listen() {
        if (!active) return
        if (paused) {
            handler.postDelayed({ listen() }, 1500)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            active = false
            stopSelf()
            return
        }
        try {
            rec?.destroy()
        } catch (e: Exception) {
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}

            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    active = false
                    stopSelf()
                    return
                }
                val delay = if (error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                ) 300L else 1500L
                handler.postDelayed({ listen() }, delay)
            }

            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                var handled = false
                if (list != null) {
                    for (t in list) {
                        val m = wake.find(t)
                        if (m != null) {
                            openApp(m.groupValues[2].trim())
                            handled = true
                            break
                        }
                    }
                }
                handler.postDelayed({ listen() }, if (handled) 4000L else 300L)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, getSharedPreferences("jv", 0).getString("lang", "es-MX") ?: "es-MX")
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        try {
            r.startListening(i)
        } catch (e: Exception) {
            handler.postDelayed({ listen() }, 2000)
        }
    }

    private fun openApp(cmd: String) {
        val c = if (cmd.isEmpty()) "saludo" else "orden: " + cmd
        val i = Intent(this, MainActivity::class.java)
        i.putExtra("cmd", c)
        i.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        )
        if (Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
            }
        }
        Reminders.notify(
            this, 2, "Jarvis",
            if (cmd.isEmpty()) "Toque para hablar con Jarvis" else "Toque para ejecutar: " + cmd,
            c
        )
    }

    override fun onDestroy() {
        active = false
        handler.removeCallbacksAndMessages(null)
        try {
            rec?.destroy()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
