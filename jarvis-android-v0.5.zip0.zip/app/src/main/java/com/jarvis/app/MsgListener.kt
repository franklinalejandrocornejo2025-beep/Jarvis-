package com.jarvis.app

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MsgListener : NotificationListenerService() {
    companion object {
        @Volatile var last: StatusBarNotification? = null
        @Volatile var who = ""

        fun reply(ctx: Context, text: String): String {
            val n = last ?: return "none"
            val acts = n.notification.actions ?: return "none"
            for (a in acts) {
                val ri = a.remoteInputs ?: continue
                if (ri.isEmpty()) continue
                val i = Intent()
                val b = Bundle()
                for (r in ri) b.putCharSequence(r.resultKey, text)
                android.app.RemoteInput.addResultsToIntent(ri, i, b)
                return try { a.actionIntent.send(ctx, 0, i); "ok" } catch (e: Exception) { "error" }
            }
            return "none"
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = when (sbn.packageName) {
            "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"
            "com.google.android.gm" -> "Gmail"
            "org.telegram.messenger" -> "Telegram"
            "com.facebook.orca" -> "Messenger"
            "com.microsoft.office.outlook" -> "Outlook"
            "com.google.android.apps.messaging", "com.samsung.android.messaging" -> "Mensajes"
            else -> return
        }
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val e = n.extras
        val t = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val x = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (n.actions?.any { a -> a.remoteInputs?.isNotEmpty() == true } == true) {
            last = sbn
            who = app + " · " + t
        }
        MainActivity.notif(app, t, x)
    }
}
