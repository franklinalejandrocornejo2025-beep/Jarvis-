package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccess : AccessibilityService() {
    companion object {
        @Volatile var inst: JarvisAccess? = null

        private fun collect(n: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
            if (n == null || depth > 25 || out.length > 2500) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) out.append(t.trim()).append(". ")
            for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
        }

        fun read(): String {
            val r = inst?.rootInActiveWindow ?: return ""
            val sb = StringBuilder()
            collect(r, sb, 0)
            return sb.toString()
        }

        fun tap(text: String): String {
            val s = inst ?: return "off"
            val r = s.rootInActiveWindow ?: return "none"
            val list = r.findAccessibilityNodeInfosByText(text)
            if (list.isNullOrEmpty()) return "none"
            var n: AccessibilityNodeInfo? = list[0]
            while (n != null && !n.isClickable) n = n.parent
            val target = n ?: list[0]
            return if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "ok" else "fail"
        }

        fun type(text: String): String {
            val s = inst ?: return "off"
            val f = s.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "none"
            val b = Bundle()
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "ok" else "fail"
        }

        fun swipe(dir: String): String {
            val s = inst ?: return "off"
            val dm = s.resources.displayMetrics
            val w = dm.widthPixels.toFloat()
            val h = dm.heightPixels.toFloat()
            val p = Path()
            when (dir) {
                "up" -> { p.moveTo(w / 2, h * 0.7f); p.lineTo(w / 2, h * 0.3f) }
                "down" -> { p.moveTo(w / 2, h * 0.3f); p.lineTo(w / 2, h * 0.7f) }
                "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
                else -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build()
            return if (s.dispatchGesture(g, null, null)) "ok" else "fail"
        }

        fun glob(a: String): String {
            val s = inst ?: return "off"
            val c = when (a) {
                "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                else -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            }
            return if (s.performGlobalAction(c)) "ok" else "fail"
        }
    }

    override fun onServiceConnected() { inst = this }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
