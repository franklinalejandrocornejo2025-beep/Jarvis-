package com.jarvis.app

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MsgListener : NotificationListenerService() {
    companion object {
        @Volatile var last: StatusBarNotification? = null
        @Volatile var who = ""

        private val apps = mapOf(
            "com.whatsapp" to "WhatsApp",
            "com.whatsapp.w4b" to "WhatsApp Business",
            "org.telegram.messenger" to "Telegram",
            "com.google.android.apps.messaging" to "Mensajes",
            "com.samsung.android.messaging" to "Mensajes",
            "com.android.mms" to "Mensajes",
            "com.facebook.orca" to "Messenger",
            "org.thoughtcrime.securesms" to "Signal"
        )

        fun reply(ctx: Context, text: String): String {
            val n = last ?: return "none"
            val acts = n.notification.actions ?: return "none"
            for (a in acts) {
                val ri = a.remoteInputs ?: continue
                if (ri.isEmpty()) continue
                val i = Intent()
                val b = Bundle()
                for (r in ri) b.putCharSequence(r.resultKey, text)
                android.app.RemoteInput.addResultsToIntent(ri, i, b)
                return try { a.actionIntent.send(ctx, 0, i); "ok" } catch (e: Exception) { "error" }
            }
            return "none"
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = apps[sbn.packageName] ?: return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val e = n.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (text.isBlank()) return
        if (n.actions?.any { a -> a.remoteInputs?.isNotEmpty() == true } == true) {
            last = sbn
            who = "$app · $title"
        }
        MainActivity.notif(app, title, text)
    }
}
