package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsInfo = "iniciando"
    private var recognizer: SpeechRecognizer? = null

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread {
                val t = tts
                if (t == null || !ttsReady) {
                    js("onNativeSpeech('error')")
                } else {
                    val b = Bundle()
                    b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f)
                    val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, b, "jarvis")
                    if (r != TextToSpeech.SUCCESS) {
                        ttsInfo = "speak fallo $r"
                        js("onNativeSpeech('error')")
                    }
                }
            }
        }

        @JavascriptInterface
        fun status(): String = ttsInfo

        @JavascriptInterface
        fun voices(): String {
            val t = tts ?: return "[]"
            return try {
                val arr = JSONArray()
                val list = t.voices?.filter { it.locale.language == "es" }?.sortedBy { it.name } ?: emptyList()
                for (v in list) {
                    val o = JSONObject()
                    o.put("n", v.name)
                    o.put("l", v.locale.toString())
                    o.put("net", v.isNetworkConnectionRequired)
                    arr.put(o)
                }
                arr.toString()
            } catch (e: Exception) {
                "[]"
            }
        }

        @JavascriptInterface
        fun setVoice(name: String) {
            runOnUiThread {
                val t = tts
                val v = t?.voices?.firstOrNull { it.name == name }
                if (t != null && v != null) {
                    t.voice = v
                    ttsInfo = "voz $name"
                }
            }
        }

        @JavascriptInterface
        fun setPitchRate(pitch: Double, rate: Double) {
            runOnUiThread {
                tts?.setPitch(pitch.toFloat())
                tts?.setSpeechRate(rate.toFloat())
            }
        }

        @JavascriptInterface
        fun findContact(name: String): String {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 3) }
                return "{\"ok\":false,\"err\":\"perm\"}"
            }
            return try {
                var res = "{\"ok\":false,\"err\":\"none\"}"
                val c = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    ),
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    arrayOf("%" + name + "%"),
                    null
                )
                c?.use {
                    if (it.moveToFirst()) {
                        val o = JSONObject()
                        o.put("ok", true)
                        o.put("name", it.getString(0))
                        o.put("number", it.getString(1))
                        res = o.toString()
                    }
                }
                res
            } catch (e: Exception) {
                "{\"ok\":false,\"err\":\"error\"}"
            }
        }

        @JavascriptInterface
        fun call(number: String): String {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 4) }
                return "perm"
            }
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
                } catch (e: Exception) {
                }
            }
            return "ok"
        }

        @JavascriptInterface
        fun email(to: String, subject: String, body: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + to))
                    i.putExtra(Intent.EXTRA_SUBJECT, subject)
                    i.putExtra(Intent.EXTRA_TEXT, body)
                    startActivity(i)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun calendarToday(): String {
            if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 5) }
                return "{\"ok\":false,\"err\":\"perm\"}"
            }
            return try {
                val cal = Calendar.getInstance()
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                val start = cal.timeInMillis
                val end = start + 24L * 60L * 60L * 1000L
                val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
                ContentUris.appendId(b, start)
                ContentUris.appendId(b, end)
                val arr = JSONArray()
                val c = contentResolver.query(
                    b.build(),
                    arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
                    null,
                    null,
                    CalendarContract.Instances.BEGIN + " ASC"
                )
                c?.use {
                    while (it.moveToNext()) {
                        val o = JSONObject()
                        o.put("t", it.getString(0) ?: "Sin título")
                        o.put("s", it.getLong(1))
                        arr.put(o)
                    }
                }
                val res = JSONObject()
                res.put("ok", true)
                res.put("events", arr)
                res.toString()
            } catch (e: Exception) {
                "{\"ok\":false,\"err\":\"error\"}"
            }
        }

        @JavascriptInterface
        fun listen() {
            runOnUiThread { startListening() }
        }

        @JavascriptInterface
        fun stopListening() {
            runOnUiThread { recognizer?.stopListening() }
        }

        @JavascriptInterface
        fun stop() {
            runOnUiThread { tts?.stop() }
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            js("onNativeListen('error:9')")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("onNativeListen('error:na')")
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { js("onNativeListen('start')") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { js("onNativeListen('error:$error')") }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()
                if (text.isNullOrBlank()) {
                    js("onNativeListen('error:7')")
                } else {
                    js("onNativeHeard(" + JSONObject.quote(text) + ")")
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        r.startListening(i)
    }

    private fun initVoice(status: Int) {
        val t = tts
        if (status != TextToSpeech.SUCCESS || t == null) {
            ttsInfo = "fallo init $status"
            return
        }
        var chosen: Locale? = null
        for (loc in listOf(Locale("es", "MX"), Locale("es", "ES"), Locale("es", "US"), Locale("es"))) {
            val r = t.setLanguage(loc)
            if (r >= TextToSpeech.LANG_AVAILABLE) {
                chosen = loc
                break
            }
        }
        ttsInfo = if (chosen != null) "voz $chosen" else "sin español, voz por defecto"
        ttsReady = true
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setPitch(0.6f)
        t.setSpeechRate(0.95f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { js("onNativeSpeech('start')") }
            override fun onDone(utteranceId: String?) { js("onNativeSpeech('end')") }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                ttsInfo = "error de voz"
                js("onNativeSpeech('error')")
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                ttsInfo = "error de voz $errorCode"
                js("onNativeSpeech('error')")
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ), 1
        )

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setGeolocationEnabled(true)
        }

        web.addJavascriptInterface(Bridge(), "AndroidTTS")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                callback.invoke(origin, true, false)
            }
        }

        tts = TextToSpeech(this) { status ->
            Handler(Looper.getMainLooper()).post { initVoice(status) }
        }

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
