package com.jarvis.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MsgListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = when (sbn.packageName) {
            "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"
            "com.google.android.gm" -> "Gmail"
            "org.telegram.messenger" -> "Telegram"
            "com.facebook.orca" -> "Messenger"
            "com.microsoft.office.outlook" -> "Outlook"
            "com.google.android.apps.messaging", "com.samsung.android.messaging" -> "Mensajes"
            else -> return
        }
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val e = n.extras
        val t = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val x = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        MainActivity.notif(app, t, x)
    }
}
