package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsInfo = "iniciando"

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread {
                val t = tts
                if (t == null || !ttsReady) {
                    js("onNativeSpeech('error')")
                } else {
                    val b = Bundle()
                    b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f)
                    val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, b, "jarvis")
                    if (r != TextToSpeech.SUCCESS) {
                        ttsInfo = "speak fallo $r"
                        js("onNativeSpeech('error')")
                    }
                }
            }
        }

        @JavascriptInterface
        fun status(): String = ttsInfo

        @JavascriptInterface
        fun stop() {
            runOnUiThread { tts?.stop() }
        }
    }

    private fun initVoice(status: Int) {
        val t = tts
        if (status != TextToSpeech.SUCCESS || t == null) {
            ttsInfo = "fallo init $status"
            return
        }
        var chosen: Locale? = null
        for (loc in listOf(Locale("es", "MX"), Locale("es", "ES"), Locale("es", "US"), Locale("es"))) {
            val r = t.setLanguage(loc)
            if (r >= TextToSpeech.LANG_AVAILABLE) {
                chosen = loc
                break
            }
        }
        ttsInfo = if (chosen != null) "voz $chosen" else "sin español, voz por defecto"
        ttsReady = true
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setPitch(0.6f)
        t.setSpeechRate(0.95f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { js("onNativeSpeech('start')") }
            override fun onDone(utteranceId: String?) { js("onNativeSpeech('end')") }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                ttsInfo = "error de voz"
                js("onNativeSpeech('error')")
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                ttsInfo = "error de voz $errorCode"
                js("onNativeSpeech('error')")
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ), 1
        )

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setGeolocationEnabled(true)
        }

        web.addJavascriptInterface(Bridge(), "AndroidTTS")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                callback.invoke(origin, true, false)
            }
        }

        tts = TextToSpeech(this) { status ->
            Handler(Looper.getMainLooper()).post { initVoice(status) }
        }

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
