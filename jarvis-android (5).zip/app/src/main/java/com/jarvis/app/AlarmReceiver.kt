package com.jarvis.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra("kind") ?: return
        val id = intent.getIntExtra("id", 0)
        val text = intent.getStringExtra("text") ?: ""
        if (kind == "summary") {
            Reminders.notify(context, 1, "Buenos días", "Toque para escuchar su resumen del día", "resumen")
            Reminders.scheduleSummary(context)
        } else {
            Reminders.notify(context, id, "Recordatorio", text, "recordatorio: " + text)
            val arr = Reminders.load(context)
            val keep = JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getInt("id") != id) keep.put(o)
            }
            Reminders.save(context, keep)
        }
    }
}
